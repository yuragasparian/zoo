import React, { useState } from 'react';
import { db, collection, addDoc } from '../../../data/firebase';
import Animal from './../Animal';
import "./AddAnimal.css"


function AddAnimal({ onAnimalAdded }) {
    const [animalDetails, setAnimalDetails] = useState({
        name: '',
        color: '',
        age: '',
        group: 'mammals',
        img: 'https://example.com/default-animal.jpg',
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setAnimalDetails(prevDetails => ({
            ...prevDetails,
            [name]: value,
        }));
    };

    const handleSubmit = async () => {
        const { group, name, color, age, img } = animalDetails;
        const newAnimal = new Animal(group, name, color, parseInt(age), img);
    
        try {
            const docRef = await addDoc(collection(db, "animals"), {
                group: newAnimal.group,
                name: newAnimal.name,
                color: newAnimal.color,
                age: newAnimal.age,
                img: newAnimal.img,
            });
            onAnimalAdded({ id: docRef.id, ...newAnimal });
    
            // Reset input fields
            setAnimalDetails({
                name: '',
                color: '',
                age: '',
                group: 'mammals',
                img: 'https://example.com/default-animal.jpg',
            });
        } catch (error) {
            console.error("Error adding animal: ", error);
        }
    };

    return (
        <div className="add-animal">
            <h1>Add an animal.</h1>
            <div className="div-form">
                <form onSubmit={(e) => e.preventDefault()}>
                    <label htmlFor="name">Animal Name</label>
                    <input type="text" id="name" name="name" placeholder="Lion" value={animalDetails.name} onChange={handleChange} />

                    <label htmlFor="color">Animal Color</label>
                    <input type="text" id="color" name="color" placeholder="Brown" value={animalDetails.color} onChange={handleChange} />

                    <label htmlFor="age">Animal Age</label>
                    <input type="number" id="age" name="age" placeholder="10" min={1} value={animalDetails.age} onChange={handleChange} />

                    <label htmlFor="img">Image URL</label>
                    <input type="text" id="img" name="img" placeholder="https://example.com/animal.jpg" value={animalDetails.img} onChange={handleChange} />

                    <label htmlFor="group">Group</label>
                    <select id="group" name="group" value={animalDetails.group} onChange={handleChange}>
                        <option value="mammals">Mammals</option>
                        <option value="birds">Birds</option>
                        <option value="reptiles">Reptiles</option>
                        <option value="amphibians">Amphibians</option>
                        <option value="fish">Fish</option>
                        <option value="other">Other</option>
                    </select>

                    <input type="button" value="Submit" onClick={handleSubmit} />
                </form>
            </div>
        </div>
    );
}

export default AddAnimal;
