class Animal {
    constructor(group, name, color, age, img) {
        this.group = group;
        this.name = name;
        this.color = color;
        this.age = age;
        this.img = img;
    }
}

export default Animal;
