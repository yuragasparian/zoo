import React, { useState, useEffect } from 'react';
import {  db, collection, getDocs } from '../data/firebase';
import AddAnimal from './components/addAnimal/AddAnimal';
import AnimalCard from './components/animalCard/AnimalCard';
import './App.css'



function App() {
    const [animalsData, setAnimalsData] = useState([]);

    useEffect(() => {
        const fetchAnimals = async () => {
            const animalsCollection = collection(db, "animals");
            const animalSnapshot = await getDocs(animalsCollection);
            const animalList = animalSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            setAnimalsData(animalList);
        };

        fetchAnimals();
    }, []);

    return (
        <>
            <div className='home'>
                <div id='container'>
                    {animalsData.map((animal, index) =>
                        <AnimalCard key={index} animal={animal} />
                    )}
                </div>
                <AddAnimal onAnimalAdded={(newAnimal) => setAnimalsData([...animalsData, newAnimal])} />
            </div>
        </>
    );
}

export default App;

