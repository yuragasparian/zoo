// firebase.js
import { initializeApp } from "firebase/app";
import { getFirestore, collection, addDoc, getDocs } from "firebase/firestore";

const firebaseConfig = {

    apiKey: "AIzaSyBIJwsErQ0nJVh9E2skgS8Vz2G4hcRwNFY",
  
    authDomain: "react-test-database-6b6ca.firebaseapp.com",
  
    projectId: "react-test-database-6b6ca",
  
    storageBucket: "react-test-database-6b6ca.firebasestorage.app",
  
    messagingSenderId: "423439438883",
  
    appId: "1:423439438883:web:7378b6ce69904519b34d96"
  
  };
  

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

export { db, collection, addDoc, getDocs };
