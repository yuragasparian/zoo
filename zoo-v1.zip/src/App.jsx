
import { animasData } from '../data/Animals';
import './App.css'
import AddAnimal from './components/addAnimal/AddAnimal';
import AnimalCard from './components/animalCard/AnimalCard';
import React from 'react';




class Animal {
    constructor(group, name, color, age, img) {
        this.group = group;
        this.name = name;
        this.color = color;
        this.age = age;
        this.img = img;
    }
}

animasData.push(new Animal("Mammals", "Lion", "Brown", 10, "https://wwfgifts-files.worldwildlife.org/wwfgifts/images/lion-large-photo.jpg"), new Animal("Mammals", "Wolf", "Gray", 8, "https://wwfeu.awsassets.panda.org/img/w01049_dsc2169_20090911_8100a_wolf__c__ralph_frank_wwf_546040.jpg"))

function App() {

    return (
        <>
        <div className='home'>
            <div id='container'>
                {animasData.map((animal, index) =>
                    <AnimalCard key={index} animal={animal} />
                )}

            </div>
            <AddAnimal />
            </div>
        </>
    )
}




export default App
