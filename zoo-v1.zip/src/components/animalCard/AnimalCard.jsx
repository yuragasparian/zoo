import "./AnimalCard.css"

export default ({animal}) => (
    <div className='animal-card'>
        <img src={animal.img} alt={animal.name} />
        <h3>{animal.name}</h3>
        <p>Color: {animal.color}</p>
        <p>Age: {animal.age}</p>
        
    </div>

)