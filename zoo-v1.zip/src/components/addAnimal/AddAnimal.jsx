import { animasData } from "../../../data/Animals"
import "./AddAnimal.css"    
class Animal {
    constructor(group, name, color, age, img) {
        this.group = group;
        this.name = name;
        this.color = color;
        this.age = age;
        this.img = img;
    }
}
export default () => (
    <>
        <div className="add-animal">
            <h1>add an animal.</h1>
            <div className="div-form">
            <form>
                <label htmlFor="fname">Animal Name</label>
                <input type="text" id="name" name="name" placeholder="Lion" />

                <label htmlFor="lname">Animal Color</label>
                <input type="text" id="color" name="color" placeholder="Brown" />

                <label htmlFor="lname">Animal Age</label>
                <input type="number" id="age" name="age" placeholder="10" min={1} />

                <label htmlFor="group">Group</label>
                <select id="group" name="group">
                    <option value="mammals">Mammals</option>
                    <option value="birds">Birds</option>
                    <option value="reptiles">Reptiles</option>
                    <option value="amphibians">Amphibians</option>
                    <option value="fish">Fish</option>
                    <option value="other">Other</option>
                </select>

                <input type="button" value="Submit" onClick={() => animasData.push(new Animal("Mammals", "Lion", "Brown", 10, "https://wwfgifts-files.worldwildlife.org/wwfgifts/images/lion-large-photo.jpg"))} />
            </form>
        </div>
        </div>
        
    </>
)